# Split Log

A four-day, mobile-first gym tracker with set-by-set weight and reps, workout history, personal bests, local browser storage, JSON export/import, and offline support.

## Publish with GitHub Pages

1. Upload `index.html`, `manifest.webmanifest`, `service-worker.js`, and `icon.svg` to the **root** of your GitHub repository (not inside a folder).
2. In GitHub repository **Settings → Pages**, under **Build and deployment**, choose **Deploy from a branch**.
3. Select branch **main**, folder **/(root)**, and tap **Save**.
4. Wait for GitHub Pages to show your live URL. For the `apple99222004-lab/Split-Log` repository, the expected URL is `https://apple99222004-lab.github.io/Split-Log/` once successfully published.
5. Open that URL in iPhone Safari → Share → Add to Home Screen.

Workout records remain in local browser storage on the device. Export backups regularly. GitHub Pages publishes the application code, **not** your workout data. The app has no cloud sync. Clearing browser/site data can erase logs. The service worker provides offline use after an initial successful visit.
